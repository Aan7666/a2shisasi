import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'; // Mengganti ReactiveFormsModule ke FormsModule biasa
import { IonicModule } from '@ionic/angular';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule] // Menggunakan FormsModule di sini
})
export class LoginPage implements OnInit {

  // Menyimpan data input langsung ke properti string biasa
  username: string = '';
  password: string = '';
  
  isLoading: boolean = false;
  showPassword: boolean = false;

  constructor(
    private router: Router,
    private authService: AuthService
  ) { }

  ngOnInit() {
    // Fungsi initForm() dihapus karena tidak menggunakan FormBuilder/FormGroup lagi
  }

  togglePassword() {
    this.showPassword = !this.showPassword;
  }

  onLogin() {
    // Validasi manual menggunakan manipulasi string biasa
    if (!this.username || !this.username.trim() || !this.password) {
      alert('Please enter both username/email and password.');
      return;
    }

    this.isLoading = true;

    // Nilai dikirim langsung mengambil dari properti kelas (this.username & this.password)
    this.authService.login(this.username, this.password).subscribe({
      next: (result) => {
        this.isLoading = false;
        if (result.success) {
          alert(result.message || 'Login successful!');
          this.router.navigate(['/tabs']);
        } else {
          alert(result.message || 'Login failed.');
        }
      },
      error: (err) => {
        this.isLoading = false;
        console.error(err);
        const errMsg = err.error?.message || 'Email atau password salah!';
        alert(errMsg);
      }
    });
  }

  LoginGoogle() {
    console.log('Login dengan Google...');
    this.isLoading = true;

    const mockGoogleEmail = 'google.user@example.com';
    this.authService.register({
      email: mockGoogleEmail,
      fullName: 'Google User',
      password: 'google_password'
    });
    this.authService.loginLocal(mockGoogleEmail, 'google_password');

    this.isLoading = false;
    alert('Google Login successful!');
    this.router.navigate(['/tabs']);
  }

  goToSignUp() {
    this.router.navigate(['/register']);
  }

  goHome() {
    this.router.navigate(['/tabs/home']);
  }
}